package com.sweethome.mapper;

public class ProductMapper {

}

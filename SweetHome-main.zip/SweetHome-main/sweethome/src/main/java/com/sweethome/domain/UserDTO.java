package com.sweethome.domain;

import lombok.Data;

@Data
public class UserDTO {
   private String userid;
   private String userpw;
   private String username;
   private String usergender;
   private String zipcode;
   private String useraddr;
   private String useraddrdetail;
   private String useraddretc;
   private String userbirth;
   private String userphone;
   private String userphoto;
}

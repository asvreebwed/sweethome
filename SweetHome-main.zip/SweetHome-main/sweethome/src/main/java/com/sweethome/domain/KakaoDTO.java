package com.sweethome.domain;

import lombok.Data;

@Data
public class KakaoDTO {
	String userid;
	String username;
	String email;
}

package com.sweethome.domain;

import lombok.Data;

@Data
public class ProductDTO {
	private String productnum;
	private String productname;
	private int productamount;
	private String productcontents;
	private String productphoto;
}
